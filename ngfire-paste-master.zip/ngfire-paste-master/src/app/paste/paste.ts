export class Paste {
    createdAt: number;
    lang: string;
    title: string;
    content: string;
    owner: string;
    priority?: number;
}
