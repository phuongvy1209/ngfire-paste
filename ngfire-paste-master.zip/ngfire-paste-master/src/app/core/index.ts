export * from './footer/footer.component';
export * from './navbar/navbar.component';
export * from './loader/loader.component';
export * from './not-found/not-found.component';

export * from './core.module';
